

const express = require('express');
const { getDirectMessages, sendDirectMessage } = require('../controllers/chatController');
const { protect } = require('../middlewares/auth');

const router = express.Router();

router.get('/direct/:otherUserId', protect, getDirectMessages);
router.post('/direct/:otherUserId/messages', protect, sendDirectMessage);

module.exports = router;
