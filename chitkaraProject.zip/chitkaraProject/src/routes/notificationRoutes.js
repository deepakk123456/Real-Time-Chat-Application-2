

const express = require('express');
const { getNotifications, markNotificationAsRead } = require('../controllers/notificationController');
const { protect } = require('../middlewares/auth');

const router = express.Router();

router.get('/', protect, getNotifications);
router.put('/:notificationId/read', protect, markNotificationAsRead);

module.exports = router;
