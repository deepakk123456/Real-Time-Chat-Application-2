
const express = require('express');
const { getUserProfile, updateUserStatus } = require('../controllers/userController');
const { protect } = require('../middlewares/auth'); // Import authentication middleware

const router = express.Router();

router.get('/:userId', protect, getUserProfile);
router.put('/:userId/status', protect, updateUserStatus);

module.exports = router;
