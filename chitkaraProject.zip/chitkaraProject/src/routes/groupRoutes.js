

const express = require('express');
const {
    createGroup,
    getUserGroups,
    getGroupMessages,
    sendGroupMessage,
    addGroupMembers,
    removeGroupMember,
} = require('../controllers/groupController');
const { protect } = require('../middlewares/auth');

const router = express.Router();

router.post('/', protect, createGroup);
router.get('/', protect, getUserGroups);
router.get('/:groupId/messages', protect, getGroupMessages);
router.post('/:groupId/messages', protect, sendGroupMessage);
router.post('/:groupId/members', protect, addGroupMembers);
router.delete('/:groupId/members/:userId', protect, removeGroupMember);

module.exports = router;
