

const mongoose = require('mongoose');

const messageSchema = mongoose.Schema(
    {
        sender: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        },
        receiver: { // For direct messages
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: false, // Not required for group messages
        },
        group: { // For group messages
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Group',
            required: false, // Not required for direct messages
        },
        content: {
            type: String,
            required: true,
        },
        contentType: {
            type: String,
            enum: ['text', 'image', 'video', 'file'],
            default: 'text',
        },
        mediaUrl: {
            type: String,
            required: false, // Only for image/video/file content
        },
        readBy: [ // For tracking read status in direct messages
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User',
            },
        ],
    },
    {
        timestamps: true,
    }
);

const Message = mongoose.model('Message', messageSchema);

module.exports = Message;
