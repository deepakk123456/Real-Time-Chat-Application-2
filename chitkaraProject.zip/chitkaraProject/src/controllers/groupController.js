

// src/controllers/groupController.js
// Logic for group chats

const Group = require('../models/Group');
const Message = require('../models/Message');
const User = require('../models/User');

// @desc    Create a new group chat
// @route   POST /api/groups
// @access  Private
const createGroup = async (req, res, next) => {
    const { name, description, members } = req.body;
    const adminId = req.user._id; // Current authenticated user is the admin

    try {
        if (!name || !members || members.length === 0) {
            res.status(400);
            throw new Error('Group name and at least one member are required');
        }

        // Ensure the admin is also a member
        if (!members.includes(adminId.toString())) {
            members.push(adminId.toString());
        }

        // Check if all provided members exist
        const existingMembers = await User.find({ _id: { $in: members } });
        if (existingMembers.length !== members.length) {
            res.status(400);
            throw new Error('One or more provided members do not exist');
        }

        const newGroup = await Group.create({
            name,
            description,
            members,
            admin: adminId,
        });

        res.status(201).json({
            groupId: newGroup._id,
            message: 'Group created successfully',
            group: newGroup,
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get list of groups the user is a member of
// @route   GET /api/groups
// @access  Private
const getUserGroups = async (req, res, next) => {
    const userId = req.user._id;

    try {
        const groups = await Group.find({ members: userId }).populate('members', 'username'); // Populate members for display

        // For each group, get the last message (optional, can be optimized)
        const groupsWithLastMessage = await Promise.all(groups.map(async (group) => {
            const lastMessage = await Message.findOne({ group: group._id })
                .sort({ createdAt: -1 })
                .limit(1)
                .populate('sender', 'username'); // Populate sender of the last message

            return {
                ...group.toObject(), // Convert Mongoose document to plain object
                memberCount: group.members.length,
                lastMessage: lastMessage ? lastMessage.toObject() : null,
            };
        }));

        res.json(groupsWithLastMessage);
    } catch (error) {
        next(error);
    }
};

// @desc    Get messages from a specific group chat
// @route   GET /api/groups/:groupId/messages
// @access  Private
const getGroupMessages = async (req, res, next) => {
    const { groupId } = req.params;
    const userId = req.user._id;
    const { limit = 50, before } = req.query;

    try {
        const group = await Group.findById(groupId);
        if (!group) {
            res.status(404);
            throw new Error('Group not found');
        }

        // Check if the current user is a member of the group
        if (!group.members.includes(userId)) {
            res.status(403);
            throw new Error('Not authorized to view messages in this group');
        }

        const query = { group: groupId };
        if (before) {
            query.createdAt = { $lt: new Date(before) };
        }

        const messages = await Message.find(query)
            .sort({ createdAt: -1 })
            .limit(parseInt(limit))
            .populate('sender', 'username');

        res.json(messages.reverse());
    } catch (error) {
        next(error);
    }
};

// @desc    Send a new message to a group chat
// @route   POST /api/groups/:groupId/messages
// @access  Private
const sendGroupMessage = async (req, res, next) => {
    const { groupId } = req.params;
    const { content, contentType, mediaUrl } = req.body;
    const senderId = req.user._id;

    try {
        const group = await Group.findById(groupId);
        if (!group) {
            res.status(404);
            throw new Error('Group not found');
        }

        // Check if the current user is a member of the group
        if (!group.members.includes(senderId)) {
            res.status(403);
            throw new Error('Not authorized to send messages to this group');
        }

        if (!content && !mediaUrl) {
            res.status(400);
            throw new Error('Message content or media URL is required');
        }

        const newMessage = await Message.create({
            sender: senderId,
            group: groupId,
            content,
            contentType,
            mediaUrl,
        });

        // TODO: Emit WebSocket event to all group members
        // io.to(groupId).emit('newGroupMessage', newMessage);

        res.status(201).json({
            messageId: newMessage._id,
            status: 'sent',
            message: newMessage,
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Add members to a group
// @route   POST /api/groups/:groupId/members
// @access  Private (only group admin can add members)
const addGroupMembers = async (req, res, next) => {
    const { groupId } = req.params;
    const { newMembers } = req.body; // Array of user IDs to add
    const currentUserId = req.user._id;

    try {
        const group = await Group.findById(groupId);
        if (!group) {
            res.status(404);
            throw new Error('Group not found');
        }

        // Check if current user is the admin of the group
        if (group.admin.toString() !== currentUserId.toString()) {
            res.status(403);
            throw new Error('Only the group admin can add members');
        }

        if (!newMembers || newMembers.length === 0) {
            res.status(400);
            throw new Error('No new members provided');
        }

        // Filter out members already in the group and validate new members
        const membersToAdd = newMembers.filter(memberId => !group.members.includes(memberId));
        if (membersToAdd.length === 0) {
            return res.status(200).json({ message: 'All provided users are already members of this group' });
        }

        const existingUsers = await User.find({ _id: { $in: membersToAdd } });
        if (existingUsers.length !== membersToAdd.length) {
            res.status(400);
            throw new Error('One or more new members do not exist');
        }

        group.members.push(...membersToAdd);
        await group.save();

        res.json({
            message: 'Members added successfully',
            addedMembers: membersToAdd,
            group: group,
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Remove a member from a group
// @route   DELETE /api/groups/:groupId/members/:userId
// @access  Private (only group admin can remove members)
const removeGroupMember = async (req, res, next) => {
    const { groupId, userId } = req.params;
    const currentUserId = req.user._id;

    try {
        const group = await Group.findById(groupId);
        if (!group) {
            res.status(404);
            throw new Error('Group not found');
        }

        // Check if current user is the admin of the group
        if (group.admin.toString() !== currentUserId.toString()) {
            res.status(403);
            throw new Error('Only the group admin can remove members');
        }

        // Prevent admin from removing themselves (unless they are the only member)
        if (group.admin.toString() === userId && group.members.length > 1) {
            res.status(400);
            throw new Error('Admin cannot remove themselves if there are other members. Transfer admin rights first.');
        }

        const initialMemberCount = group.members.length;
        group.members = group.members.filter(member => member.toString() !== userId);

        if (group.members.length === initialMemberCount) {
            res.status(404);
            throw new Error('User not found in this group');
        }

        await group.save();

        res.json({
            message: 'Member removed successfully',
            removedUserId: userId,
            group: group,
        });
    } catch (error) {
        next(error);
    }
};


module.exports = {
    createGroup,
    getUserGroups,
    getGroupMessages,
    sendGroupMessage,
    addGroupMembers,
    removeGroupMember,
};
