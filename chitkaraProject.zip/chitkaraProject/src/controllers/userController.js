

const getUserProfile = async (req, res, next) => {
    try {
        const user = await User.findById(req.params.userId).select('-password'); // Exclude password
        if (user) {
            res.json({
                userId: user._id,
                username: user.username,
                email: user.email,
                status: user.status,
                profilePictureUrl: user.profilePictureUrl,
            });
        } else {
            res.status(404);
            throw new Error('User not found');
        }
    } catch (error) {
        next(error);
    }
};

// @desc    Update user status
// @route   PUT /api/users/:userId/status
// @access  Private (only authenticated user can update their own status)
const updateUserStatus = async (req, res, next) => {
    const { status } = req.body;

    // Ensure the user is updating their own status
    if (req.user._id.toString() !== req.params.userId) {
        res.status(403);
        throw new Error('Not authorized to update this user\'s status');
    }

    try {
        const user = await User.findById(req.params.userId);

        if (user) {
            user.status = status || user.status; // Update status if provided

            const updatedUser = await user.save();
            res.json({
                message: 'Status updated successfully',
                status: updatedUser.status,
            });
        } else {
            res.status(404);
            throw new Error('User not found');
        }
    } catch (error) {
        next(error);
    }
};

module.exports = { getUserProfile, updateUserStatus };