

const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Helper function to generate JWT token
const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d', // Token expires in 30 days
    });
};

// @desc    Register new user
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res, next) => {
    const { username, email, password } = req.body;

    try {
        // Check if user already exists
        const userExists = await User.findOne({ email });
        if (userExists) {
            res.status(400);
            throw new Error('User already exists');
        }

        // Create new user
        const user = await User.create({
            username,
            email,
            password, // Password will be hashed by pre-save hook in User model
        });

        if (user) {
            res.status(201).json({
                message: 'User registered successfully',
                userId: user._id,
                token: generateToken(user._id),
            });
        } else {
            res.status(400);
            throw new Error('Invalid user data');
        }
    } catch (error) {
        next(error); // Pass error to centralized error handler
    }
};

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
// @access  Public

// const loginUser = async (req, res, next) => {
//     const { email, password } = req.body;

//     try {
//         // Check if user exists
//         const user = await User.findOne({ email });

//         // Check password
//         if (user && (await user.matchPassword(password))) {
//             res.json({
//                 message: 'Login successful',
//                 userId: user._id,
//                 token: generateToken(user._id),
//             });
//         } else {
//             res.status(401);
//             throw new Error('Invalid email or password');
//         }
//     } catch (error) {
//         next(error); // Pass error to centralized error handler
//     }
// };


const loginUser = async (req, res, next) => {
    const { email, password } = req.body;
    console.log(`Login attempt for email: ${email}, password: ${password}`); // DEBUG
    try {
        const user = await User.findOne({ email });
        if (!user) {
            console.log('User not found in DB.'); // DEBUG
            res.status(401);
            throw new Error('Invalid email or password');
        }

        console.log(`Found user: ${user.email}, stored hashed password: ${user.password}`); // DEBUG
        // Test password comparison
        const isMatch = await user.matchPassword(password);
        console.log(`Password match result: ${isMatch}`); // DEBUG - THIS IS CRUCIAL

        if (user && isMatch) { // Changed this to use `isMatch` directly
            res.json({
                message: 'Login successful',
                userId: user._id,
                token: generateToken(user._id),
            });
        } else {
            res.status(401);
            throw new Error('Invalid email or password'); // This will be caught by next(error)
        }
    } catch (error) {
        console.error('Login error:', error.message); // DEBUG
        next(error);
    }
};



module.exports = { registerUser, loginUser };
