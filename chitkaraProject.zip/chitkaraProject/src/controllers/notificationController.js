

const Notification = require('../models/Notification');

// @desc    Get unread notifications for the user
// @route   GET /api/notifications
// @access  Private
const getNotifications = async (req, res, next) => {
    const userId = req.user._id;

    try {
        const notifications = await Notification.find({ recipient: userId })
            .sort({ createdAt: -1 }) // Newest first
            .populate('sourceId', 'username name'); // Populate sender/group name

        res.json(notifications);
    } catch (error) {
        next(error);
    }
};

// @desc    Mark a notification as read
// @route   PUT /api/notifications/:notificationId/read
// @access  Private
const markNotificationAsRead = async (req, res, next) => {
    const { notificationId } = req.params;
    const userId = req.user._id;

    try {
        const notification = await Notification.findById(notificationId);

        if (!notification) {
            res.status(404);
            throw new Error('Notification not found');
        }

        // Ensure the notification belongs to the current user
        if (notification.recipient.toString() !== userId.toString()) {
            res.status(403);
            throw new Error('Not authorized to mark this notification as read');
        }

        notification.read = true;
        await notification.save();

        res.json({ message: 'Notification marked as read' });
    } catch (error) {
        next(error);
    }
};

module.exports = { getNotifications, markNotificationAsRead };
