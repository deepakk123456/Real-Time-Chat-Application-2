

const Message = require('../models/Message');
const User = require('../models/User');

// @desc    Get direct messages between two users
// @route   GET /api/chats/direct/:otherUserId
// @access  Private
const getDirectMessages = async (req, res, next) => {
    const { otherUserId } = req.params;
    const currentUserId = req.user._id; // From auth middleware
    const { limit = 50, before } = req.query; // Pagination

    try {
        // Find messages where current user is sender and other user is receiver, OR vice-versa
        const query = {
            $or: [
                { sender: currentUserId, receiver: otherUserId },
                { sender: otherUserId, receiver: currentUserId },
            ],
        };

        if (before) {
            query.createdAt = { $lt: new Date(before) }; // For pagination: messages older than 'before' timestamp
        }

        const messages = await Message.find(query)
            .sort({ createdAt: -1 }) // Sort by newest first
            .limit(parseInt(limit))
            .populate('sender', 'username') // Populate sender's username
            .populate('receiver', 'username'); // Populate receiver's username

        res.json(messages.reverse()); // Reverse to get chronological order
    } catch (error) {
        next(error);
    }
};

// @desc    Send a direct message
// @route   POST /api/chats/direct/:otherUserId/messages
// @access  Private
const sendDirectMessage = async (req, res, next) => {
    const { otherUserId } = req.params;
    const { content, contentType, mediaUrl } = req.body;
    const senderId = req.user._id; // From auth middleware

    try {
        // Basic validation
        if (!content && !mediaUrl) {
            res.status(400);
            throw new Error('Message content or media URL is required');
        }

        // Check if both users exist (optional but good for robustness)
        const recipientExists = await User.findById(otherUserId);
        if (!recipientExists) {
            res.status(404);
            throw new Error('Recipient user not found');
        }

        const newMessage = await Message.create({
            sender: senderId,
            receiver: otherUserId,
            content,
            contentType,
            mediaUrl,
        });

        // TODO: Emit WebSocket event for real-time delivery
        // io.to(otherUserId).emit('newDirectMessage', newMessage);
        // io.to(senderId).emit('newDirectMessage', newMessage); // Or just confirm sender

        res.status(201).json({
            messageId: newMessage._id,
            status: 'sent',
            message: newMessage, // Return the full message object
        });
    } catch (error) {
        next(error);
    }
};

module.exports = { getDirectMessages, sendDirectMessage };
