

// Handles WebSocket connections and events using Socket.IO

const setupSocketIO = (io) => {
    io.on('connection', (socket) => {
        console.log('A user connected:', socket.id);

        // Example: Join a room based on user ID for direct messages
        socket.on('joinUserRoom', (userId) => {
            socket.join(userId);
            console.log(`User ${userId} joined their personal room.`);
        });

        // Example: Join a group chat room
        socket.on('joinGroupRoom', (groupId) => {
            socket.join(groupId);
            console.log(`User ${socket.id} joined group room: ${groupId}`);
        });

        // Example: Listen for new direct messages (server-side sending)
        // This is where you would typically broadcast messages after they are saved to DB
        // For example, from your chatController, you might emit:
        // io.to(receiverId).emit('newDirectMessage', message);
        // io.to(senderId).emit('messageStatusUpdate', { messageId, status: 'delivered' });

        // Example: Listen for new group messages (server-side sending)
        // io.to(groupId).emit('newGroupMessage', message);

        socket.on('disconnect', () => {
            console.log('User disconnected:', socket.id);
        });
    });
};

module.exports = setupSocketIO;