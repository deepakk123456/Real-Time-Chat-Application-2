
// script.js
// Updated to use port 5001 for backend and socket connections
const BACKEND_URL = 'http://localhost:5002/api'; // Your backend API base URL
const SOCKET_URL = 'http://localhost:5002'; // Your Socket.IO server URL

// DOM Elements
const authScreen = document.getElementById('auth-screen');
const chatScreen = document.getElementById('chat-screen');
const showLoginBtn = document.getElementById('show-login');
const showRegisterBtn = document.getElementById('show-register');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const logoutBtn = document.getElementById('logout-btn');

const loginEmailInput = document.getElementById('login-email');
const loginPasswordInput = document.getElementById('login-password');
const loginError = document.getElementById('login-error');

const registerUsernameInput = document.getElementById('register-username');
const registerEmailInput = document.getElementById('register-email');
const registerPasswordInput = document.getElementById('register-password');
const registerError = document.getElementById('register-error');

const currentUserDisplay = document.getElementById('current-user-display');
const chatList = document.querySelector('.chat-list');
const messagesContainer = document.getElementById('messages-container');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const chatPartnerName = document.getElementById('chat-partner-name');
const chatPartnerStatus = document.getElementById('chat-partner-status');
const newGroupChatBtn = document.getElementById('new-group-chat-btn');


// State Variables
let authToken = localStorage.getItem('token');
let currentUserId = localStorage.getItem('userId');
let currentUsername = localStorage.getItem('username');
let activeChat = null; // Stores { id: '...', type: 'user'/'group', name: '...' }
let socket = null; // Socket.IO instance

// --- Utility Functions ---
function showScreen(screenId) {
    authScreen.classList.add('hidden');
    chatScreen.classList.add('hidden');
    if (screenId === 'auth') {
        authScreen.classList.remove('hidden');
    } else {
        chatScreen.classList.remove('hidden');
    }
}

function displayError(element, message) {
    element.textContent = message;
    setTimeout(() => {
        element.textContent = '';
    }, 5000);
}

function clearMessages() {
    messagesContainer.innerHTML = '';
}

/**
 * Appends a message to the chat display.
 * @param {object} message - The message object containing content, sender, and timestamp.
 * @param {boolean} isSent - True if the message was sent by the current user, false otherwise.
 */
function appendMessage(message, isSent) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(isSent ? 'sent' : 'received');

    // Add sender name for group messages or if it's a received message in direct chat
    // Ensure message.sender and message.sender.username exist before trying to access
    if (message.group || (!isSent && message.sender && message.sender._id !== currentUserId)) {
        const senderNameSpan = document.createElement('span');
        senderNameSpan.classList.add('sender-name');
        senderNameSpan.textContent = message.sender.username || 'Unknown'; // Fallback
        messageDiv.appendChild(senderNameSpan);
    }

    const contentParagraph = document.createElement('p');
    contentParagraph.textContent = message.content;
    messageDiv.appendChild(contentParagraph);

    const timestampSpan = document.createElement('span');
    timestampSpan.classList.add('timestamp');
    timestampSpan.textContent = new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    messageDiv.appendChild(timestampSpan);

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight; // Scroll to bottom
}

/**
 * Fetches data from the backend with authentication token included.
 * Handles unauthorized/forbidden responses by logging out.
 * @param {string} url - The API endpoint URL.
 * @param {object} options - Fetch options (method, body, etc.).
 * @returns {Promise<object>} - The JSON response from the API.
 * @throws {Error} If the response is not OK or authentication fails.
 */
async function fetchWithAuth(url, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`,
        ...options.headers,
    };
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
            console.error('Authentication failed, logging out.');
            logout(); // Log out if token is invalid or expired
            throw new Error('Unauthorized or Forbidden');
        }
        const errorData = await response.json();
        throw new Error(errorData.message || 'Something went wrong');
    }
    return response.json();
}

// --- Authentication Logic ---
/**
 * Handles user login form submission.
 * @param {Event} e - The submit event.
 */
async function handleLogin(e) {
    e.preventDefault();
    const email = loginEmailInput.value;
    const password = loginPasswordInput.value;

    try {
        const response = await fetch(`${BACKEND_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            displayError(loginError, errorData.message || 'Login failed');
            return;
        }

        const data = await response.json();
        authToken = data.token;
        currentUserId = data.userId;
        localStorage.setItem('token', authToken);
        localStorage.setItem('userId', currentUserId);
        
        await fetchCurrentUserDetails(); // Fetch username and set display
        initChat(); // Initialize chat screen
    } catch (error) {
        displayError(loginError, error.message || 'Network error');
    }
}

/**
 * Handles user registration form submission.
 * @param {Event} e - The submit event.
 */
async function handleRegister(e) {
    e.preventDefault();
    const username = registerUsernameInput.value;
    const email = registerEmailInput.value;
    const password = registerPasswordInput.value;

    try {
        const response = await fetch(`${BACKEND_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            displayError(registerError, errorData.message || 'Registration failed');
            return;
        }

        const data = await response.json();
        authToken = data.token;
        currentUserId = data.userId;
        currentUsername = username; // Set username directly after successful registration
        localStorage.setItem('token', authToken);
        localStorage.setItem('userId', currentUserId);
        localStorage.setItem('username', currentUsername); // Store username
        initChat(); // Initialize chat screen
    }
    catch (error) {
        displayError(registerError, error.message || 'Network error');
    }
}

/**
 * Logs out the current user, clears local storage, and resets UI.
 */
function logout() {
    authToken = null;
    currentUserId = null;
    currentUsername = null;
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    if (socket) {
        socket.disconnect(); // Disconnect Socket.IO
        socket = null;
    }
    showScreen('auth');
    loginForm.reset();
    registerForm.reset();
    loginError.textContent = '';
    registerError.textContent = '';
    currentUserDisplay.textContent = 'Chat App'; // Reset display
    chatList.innerHTML = ''; // Clear chat list
    clearMessages(); // Clear messages
    chatPartnerName.textContent = 'Select a Chat';
    chatPartnerStatus.className = 'status-indicator';
    activeChat = null;
}

/**
 * Fetches the current user's details (username, status) from the backend.
 * Updates `currentUsername` and the display.
 */
async function fetchCurrentUserDetails() {
    if (!currentUserId || !authToken) return;
    try {
        const user = await fetchWithAuth(`${BACKEND_URL}/users/${currentUserId}`);
        currentUsername = user.username;
        localStorage.setItem('username', currentUsername); // Ensure username is in local storage
        currentUserDisplay.textContent = `Welcome, ${currentUsername}!`;
    } catch (error) {
        console.error('Failed to fetch current user details:', error);
        // This error might occur if the token is valid but user ID is not found,
        // or if the backend /users/:userId endpoint has issues.
        displayError(loginError, 'Failed to load user data. Please try logging in again.');
        logout(); // Consider logging out if user data cannot be fetched
    }
}

// --- Chat Initialization & Display ---
/**
 * Initializes the chat application after successful authentication.
 * Shows chat screen, connects to Socket.IO, and fetches chat list.
 */
async function initChat() {
    if (!authToken || !currentUserId) {
        showScreen('auth');
        return;
    }

    await fetchCurrentUserDetails(); // Ensure username is loaded
    showScreen('chat');
    connectSocket(); // Establish WebSocket connection
    fetchChats(); // Populate chat list
}

/**
 * Fetches a list of other users for direct messaging.
 * @returns {Promise<Array>} - An array of user objects, excluding the current user.
 */
async function fetchUsersForDirectChat() {
    try {
        const users = await fetchWithAuth(`${BACKEND_URL}/users`);
        // Ensure users is an array before filtering
        return Array.isArray(users) ? users.filter(user => user._id !== currentUserId) : [];
    } catch (error) {
        console.error('Error fetching users for direct chat:', error);
        return []; // Return empty array on error
    }
}

/**
 * Fetches and displays the list of direct chats and group chats.
 */
async function fetchChats() {
    chatList.innerHTML = ''; // Clear existing chat list

    try {
        // Fetch all other users for direct messaging
        const otherUsers = await fetchUsersForDirectChat();
        otherUsers.forEach(user => {
            const userItem = document.createElement('div');
            userItem.classList.add('chat-item');
            userItem.dataset.chatId = user._id;
            userItem.dataset.chatType = 'user';
            userItem.innerHTML = `
                <span class="chat-name">${user.username}</span>
                <span class="last-message">Tap to chat...</span>
                <span class="chat-status ${user.status || 'offline'}"></span>
            `;
            userItem.addEventListener('click', () => selectChat({ id: user._id, type: 'user', name: user.username, status: user.status }));
            chatList.appendChild(userItem);
        });

        // Fetch user's groups
        const groups = await fetchWithAuth(`${BACKEND_URL}/groups`);
        groups.forEach(group => {
            const groupItem = document.createElement('div');
            groupItem.classList.add('chat-item');
            groupItem.dataset.chatId = group._id;
            groupItem.dataset.chatType = 'group';
            // Note: group.lastMessage might not be fully populated by backend if not explicitly joined.
            // Ensure backend populates lastMessage.content and sender.username if needed.
            groupItem.innerHTML = `
                <span class="chat-name">${group.name}</span>
                <span class="last-message">${group.lastMessage && group.lastMessage.content ? group.lastMessage.content : 'No messages yet'}</span>
                <span class="chat-status offline"></span> `;
            groupItem.addEventListener('click', () => selectChat({ id: group._id, type: 'group', name: group.name }));
            chatList.appendChild(groupItem);
        });

        // Auto-select the first chat if available
        if (chatList.firstElementChild) {
            chatList.firstElementChild.click();
        }

    } catch (error) {
        console.error('Error fetching chats:', error);
        // You might want to display a user-facing error here as well
        // displayError(someElement, 'Failed to load chat list.');
    }
}

/**
 * Selects a chat (direct or group) and loads its messages.
 * @param {object} chatInfo - Object containing chat id, type, name, and optional status.
 */
async function selectChat(chatInfo) {
    // Prevent re-selecting the same active chat
    if (activeChat && activeChat.id === chatInfo.id) {
        return;
    }

    // Update active chat item styling in the sidebar
    document.querySelectorAll('.chat-item').forEach(item => item.classList.remove('active'));
    const selectedItem = document.querySelector(`.chat-item[data-chat-id="${chatInfo.id}"]`);
    if (selectedItem) {
        selectedItem.classList.add('active');
    }

    activeChat = chatInfo; // Set the newly active chat
    chatPartnerName.textContent = activeChat.name; // Update chat header name
    chatPartnerStatus.className = `status-indicator ${activeChat.status || 'offline'}`; // Update chat header status

    clearMessages(); // Clear messages from previous chat
    messageInput.value = ''; // Clear message input on chat switch

    try {
        let messages;
        if (activeChat.type === 'user') {
            // Fetch direct messages
            messages = await fetchWithAuth(`${BACKEND_URL}/chats/direct/${activeChat.id}`);
        } else if (activeChat.type === 'group') {
            // Fetch group messages
            messages = await fetchWithAuth(`${BACKEND_URL}/groups/${activeChat.id}/messages`);
        }

        // Append fetched messages to the display
        messages.forEach(msg => {
            appendMessage(msg, msg.sender._id === currentUserId);
        });
    } catch (error) {
        console.error('Error fetching messages:', error);
        appendMessage({ content: 'Failed to load messages. Please try again.', createdAt: new Date() }, false);
    }

    // Join the relevant socket room for real-time updates
    if (socket) {
        if (activeChat.type === 'user') {
            // For direct chat, current user also joins receiver's room to get their messages
            socket.emit('joinUserRoom', activeChat.id);
        } else if (activeChat.type === 'group') {
            socket.emit('joinGroupRoom', activeChat.id);
        }
        // Also ensure the current user's own room is joined for notifications
        socket.emit('joinUserRoom', currentUserId);
    }
}


// --- Message Sending Logic ---
/**
 * Handles message form submission (sending a message).
 * @param {Event} e - The submit event.
 */
async function handleMessageSubmit(e) {
    e.preventDefault();
    // Prevent sending if no chat is active or message is empty
    if (!activeChat || !messageInput.value.trim()) {
        return;
    }

    const content = messageInput.value.trim();
    messageInput.value = ''; // Clear input immediately for better UX

    try {
        let newMessageResponse; // This will hold the response from the backend
        if (activeChat.type === 'user') {
            // Send direct message
            newMessageResponse = await fetchWithAuth(`${BACKEND_URL}/chats/direct/${activeChat.id}/messages`, {
                method: 'POST',
                body: JSON.stringify({ content, contentType: 'text' }),
            });
        } else if (activeChat.type === 'group') {
            // Send group message
            newMessageResponse = await fetchWithAuth(`${BACKEND_URL}/groups/${activeChat.id}/messages`, {
                method: 'POST',
                body: JSON.stringify({ content, contentType: 'text' }),
            });
        }

        // Optimistically add message to UI.
        // The backend should return the full message object including sender details and timestamp.
        // We use newMessageResponse.message because the backend returns { messageId, status, message }
        appendMessage({ ...newMessageResponse.message, sender: { _id: currentUserId, username: currentUsername } }, true);

        // In a real-time app, the server (via WebSocket) would then broadcast this message
        // to all relevant clients (including the sender's other devices, if applicable).
        // The `socket.on('newDirectMessage')` or `socket.on('newGroupMessage')` would then
        // receive this broadcast and update the UI for other users.
    } catch (error) {
        console.error('Error sending message:', error);
        // If sending fails, display an error message in the chat area
        appendMessage({ content: `Failed to send: "${content}"`, createdAt: new Date() }, true);
        // You might also want to re-populate the input field with the failed message content
        // messageInput.value = content;
    }
}

// --- WebSocket Logic ---
/**
 * Connects to the Socket.IO server and sets up event listeners.
 */
function connectSocket() {
    // If socket already exists and is connected, do nothing
    if (socket && socket.connected) {
        return;
    }

    // Initialize Socket.IO client with authentication token
    socket = io(SOCKET_URL, {
        auth: {
            token: authToken
        }
    });

    // Event listener for successful connection
    socket.on('connect', () => {
        console.log('Socket.IO connected:', socket.id);
        // Join own user room for receiving personal notifications and direct messages
        socket.emit('joinUserRoom', currentUserId);
        // If an active chat is already selected, join its room
        if (activeChat) {
            if (activeChat.type === 'user') {
                socket.emit('joinUserRoom', activeChat.id); // Also join receiver's room for direct updates
            } else if (activeChat.type === 'group') {
                socket.emit('joinGroupRoom', activeChat.id);
            }
        }
    });

    // Event listener for disconnection
    socket.on('disconnect', (reason) => {
        console.log('Socket.IO disconnected:', reason);
        // Handle re-connection attempts or notify user about lost real-time connection
    });

    // Event listener for connection errors
    socket.on('connect_error', (error) => {
        console.error('Socket.IO connection error:', error.message);
        // Display a user-friendly error message about real-time connection issues
        // displayError(someElement, 'Real-time connection failed. Messages might not update instantly.');
    });

    // Listen for incoming direct messages broadcasted by the server
    socket.on('newDirectMessage', (message) => {
        console.log('New direct message received:', message);
        // Only append the message if it's for the currently active chat
        if (activeChat && activeChat.type === 'user' &&
            ((message.sender._id === activeChat.id && message.receiver._id === currentUserId) ||
             (message.sender._id === currentUserId && message.receiver._id === activeChat.id))) {
            appendMessage(message, message.sender._id === currentUserId);
        }
        // Re-fetch chat list to update last message preview and potentially unread counts
        fetchChats();
    });

    // Listen for incoming group messages broadcasted by the server
    socket.on('newGroupMessage', (message) => {
        console.log('New group message received:', message);
        // Only append the message if it's for the currently active group chat
        if (activeChat && activeChat.type === 'group' && message.group === activeChat.id) {
            appendMessage(message, message.sender._id === currentUserId);
        }
        // Re-fetch chat list to update last message preview and potentially unread counts
        fetchChats();
    });

    // Listen for user status updates (conceptual - requires backend to emit this)
    socket.on('userStatusUpdate', ({ userId, status }) => {
        console.log(`User ${userId} is now ${status}`);
        // Update status indicator in the chat header if it's the active chat partner
        if (activeChat && activeChat.type === 'user' && activeChat.id === userId) {
            chatPartnerStatus.className = `status-indicator ${status}`;
            activeChat.status = status; // Update local state
        }
        // Also update status in the chat list for all relevant users
        const chatItemStatusIndicator = document.querySelector(`.chat-item[data-chat-id="${userId}"] .chat-status`);
        if (chatItemStatusIndicator) {
            chatItemStatusIndicator.className = `chat-status ${status}`;
        }
    });

    // You would add more event listeners here for notifications, typing indicators, etc.
}


// --- Event Listeners ---
showLoginBtn.addEventListener('click', () => {
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
    showLoginBtn.classList.add('active');
    showRegisterBtn.classList.remove('active');
    loginError.textContent = ''; // Clear errors on switch
    registerError.textContent = '';
});

showRegisterBtn.addEventListener('click', () => {
    registerForm.classList.remove('hidden');
    loginForm.classList.add('hidden');
    showRegisterBtn.classList.add('active');
    showLoginBtn.classList.remove('active');
    loginError.textContent = ''; // Clear errors on switch
    registerError.textContent = '';
});

loginForm.addEventListener('submit', handleLogin);
registerForm.addEventListener('submit', handleRegister);
logoutBtn.addEventListener('click', logout);
messageForm.addEventListener('submit', handleMessageSubmit);
// Add listener for new group button (will need a modal/form)
newGroupChatBtn.addEventListener('click', () => alert('New group chat functionality not yet implemented.'));

// --- Initial Load ---
document.addEventListener('DOMContentLoaded', initChat);

